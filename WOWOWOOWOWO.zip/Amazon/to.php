<?php
$TO = "laja966@yahoo.com";
?>